#!/bin/sh
cd /home/root/TinyCtrl
./TinyCtrl > /dev/null & 
 

